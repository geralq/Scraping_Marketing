import requests
from bs4 import BeautifulSoup
import db

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0',
    'Accept-Language': 'en-GB,en;q=0.5',
    'Referer': 'https://google.com',
    'DNT': '1'
}

def create_url(people, country, city, datein, dateout, minPrice, maxPrice):
    range = f'nflt=price%3DEUR-{minPrice}-{maxPrice}-1'

    url = "https://www.booking.com/searchresults.en.html?checkin_month={in_month}" \
          "&checkin_monthday={in_day}&checkin_year={in_year}&checkout_month={out_month}" \
          "&checkout_monthday={out_day}&checkout_year={out_year}&group_adults={people}" \
          "&group_children=0&order=price&ss={city}%2C%20{country}&offset=0&{range}" \
        .format(in_month=str(datein.month),
                in_day=str(datein.day),
                in_year=str(datein.year),
                out_month=str(dateout.month),
                out_day=str(dateout.day),
                out_year=str(dateout.year),
                people=people,
                city=city,
                country=country,
                range=range)
    return url

def get_data(url):
    global headers
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, 'html')
    for item in soup.find_all('div', attrs={'data-testid': 'property-card'}):

        try:

            name = item.find('div', attrs={'data-testid': 'title'}).get_text()
            price = item.select('.fcab3ed991')[1].get_text()
            price = price.replace("€", "")
            ratingWords = item.select('.b5cd09854e')[1].get_text()
            ratingNum = item.select('.b5cd09854e')[0].get_text()
            distance = item.find_all('span', attrs={'data-testid': 'distance'})[0].get_text()
            address = item.find_all('span', attrs={'data-testid': 'address'})[0].get_text()
            hotelurl = item.select('.fc63351294')[1]['href']
            reviews_url = hotelurl.replace("hotel/es", "reviews/es/hotel")
            get_comments(reviews_url, name)
        except Exception as e:
            print('')

        db.insert_into_table(name, price, ratingWords, ratingNum, distance, address, hotelurl)

def get_comments(url, name):
    response = requests.get(url)
    sopa = BeautifulSoup(response.content, 'html')
    for item in sopa.find_all('li', class_='review_item'):

        nombre = item.find_all('p', class_='reviewer_name')[0].get_text()

        if(item.find('p', class_='review_pos')):
            valoracion_positiva = item.find('p', class_='review_pos').find('span', itemprop='reviewBody').text

        else:
            valoracion_positiva = " "

        if(item.find('p', class_='review_neg')):
            valoracion_negativa = item.find('p', class_='review_neg').find('span', itemprop='reviewBody').text
        else:
            valoracion_negativa = " "
        db.insert_into_table_review(nombre, valoracion_positiva, valoracion_negativa, name)

