import datetime
import data
import db

db.create_database_and_table()



if __name__ == '__main__':
    people = int(input("Insert the number of people: "))
    country = input("Insert the country: ")
    city = input("Insert the city: ")
    datein = input("Insert the date of arrival (YYYY-MM-DD): ")
    datein = datetime.datetime.strptime(datein, "%Y-%m-%d")
    dateout = input("Insert the date of departure (YYYY-MM-DD): ")
    dateout = datetime.datetime.strptime(dateout, "%Y-%m-%d")
    minPrice = int(input("Insert the minium you want to spend: "))
    maxPrice = int(input("Insert the maximum you want to spend: "))
    print("----------------------------------------------------------")

    data.get_data(data.create_url(people, country, city, datein, dateout, minPrice, maxPrice))
    print("Database created")


