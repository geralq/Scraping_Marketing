import csv
import sqlite3
import pandas as pd


conn = sqlite3.connect('database.db')
cursor = conn.cursor()
cursor.execute("select * from database_Booking;")
with open("hotel_information.csv", 'w', newline='', encoding='utf-8') as csv_file:
    csv_writer = csv.writer(csv_file)
    csv_writer.writerow([i[0] for i in cursor.description])
    csv_writer.writerows(cursor)
cursor.execute("select * from database_Booking_review;")
with open("hotel_information_reviews.csv", 'w', newline='', encoding='utf-8') as csv_file:
    csv_writer = csv.writer(csv_file)
    csv_writer.writerow([i[0] for i in cursor.description])
    csv_writer.writerows(cursor)
conn.close()
data_hotel = pd.read_csv("hotel_information.csv")
data_hotel_review = pd.read_csv("hotel_information_reviews.csv")
precios = data_hotel['precio'].tolist()
