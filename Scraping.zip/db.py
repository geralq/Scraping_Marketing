import sqlite3


def create_database_and_table():
    database = sqlite3.connect('database.db')
    sqlite_create_table_query = '''CREATE TABLE database_Booking (
                            nombre TEXT,
                            precio INTERGER,
                            reseña TEXT,
                            puntuación INTERGER,
                            distancia_del_centro TEXT,
                            localización TEXT,
                            url TEXT);'''

    sqlite_create_table_query_review = '''CREATE TABLE database_Booking_review (
                            usuario TEXT,
                            valoracion_positiva TEXT,
                            valoracion_negativa TEXT,
                            nombre_del_hotel TEXT);'''




    cursor = database.cursor()
    cursor.execute(sqlite_create_table_query)
    cursor.execute(sqlite_create_table_query_review)
    database.commit()
    cursor.close()

def insert_into_table(nombre, precio, reseña, puntuación, distancia_del_centro, localización, url):
    try:
        database = sqlite3.connect('Database.db')
        cursor = database.cursor()

        sqlite_insert_params = """INSERT INTO database_Booking
                        (nombre, precio, reseña, puntuación, distancia_del_centro, localización, url)
                        VALUES(?,?,?,?,?,?,?);"""
        data_tuple = (nombre, precio, reseña, puntuación, distancia_del_centro, localización, url)
        cursor.execute(sqlite_insert_params, data_tuple)
        database.commit()
        cursor.close()
    except sqlite3.Error as error:
        print("Failed to insert Python variable into sqlite table", error)
    finally:
        if database:
            database.close()

def insert_into_table_review(nombre, valoracion_positiva, valoracion_negativa, nombre_del_hotel):
    try:
        database = sqlite3.connect('Database.db')
        cursor = database.cursor()

        sqlite_insert_params = """INSERT INTO database_Booking_review
                            (usuario, valoracion_positiva, valoracion_negativa, nombre_del_hotel)
                            VALUES(?,?,?,?);"""
        data_tuple = (nombre, valoracion_positiva, valoracion_negativa, nombre_del_hotel)
        cursor.execute(sqlite_insert_params, data_tuple)
        database.commit()
        cursor.close()
    except sqlite3.Error as error:
         print("Failed to insert Python variable into sqlite table", error)
    finally:
        if database:
            database.close()
